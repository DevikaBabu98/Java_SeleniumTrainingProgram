package com.eg;

import com.p5.PermanentEmployee;
import com.p6.TemporaryEmployee;

public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PermanentEmployee pobj=new PermanentEmployee(0, "null",145.6f,"addr1");
		pobj.displayp();
		
		//create object of temporary employee and call display() method;
		TemporaryEmployee eobj=new TemporaryEmployee(1, "xyz",25.6f,"addr2");
		eobj.displayt();
		
		
	}

}
