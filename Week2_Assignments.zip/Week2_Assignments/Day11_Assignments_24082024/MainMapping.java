package com.Tree;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;


class State {
	String name;
	long population;

	public State(String name, long population) {
		super();
		this.name = name;
		this.population = population;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPopulation() {
		return population;
	}

	public void setPopulation(long population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "State [name=" + name + ", population=" + population + "]";
	}
}

class City {
	String name;
	double total_area;

	public City(String name, double total_area) {
		super();
		this.name = name;
		this.total_area = total_area;
	}

	@Override
	public String toString() {
		return "City [name=" + name + ", total_area=" + total_area + "]";
	}
}

public class MainMapping {

	public static void main(String[] args) {
		TreeMap<State, City> tmss = new TreeMap<>(new MyComparator());
		State s1=new State("Karnataka",500000);
		City c1=new City("Bangalore",741.0);
		State s2=new State("Tamil Nadu",400000);
		City c2=new City("Chennai",641.0);
		State s3=new State("Kerala",450000);
		City c3=new City("Trivandrum",541.0);
		tmss.put(s1,c1);
		tmss.put(s2,c2);
		tmss.put(s3,c3);
		
		Set<Entry<State,City>> sess=tmss.entrySet();
		/*Iterator<Entry<State,City>> iess=sess.iterator();
		
		while(iess.hasNext()) {
			Entry<State,City> ess=iess.next();
			System.out.println(ess.getKey()+"->"+ess.getValue());
		}*/
		
		for(Entry<State,City> ess:sess) {
			System.out.println(ess.getKey()+"->"+ess.getValue());
		}
	}

}

class MyComparator implements Comparator<State>{
	
	@Override
	public int compare(State s1,State s2) {

		return Long.compare(s2.population,s1.population);
	}
}


