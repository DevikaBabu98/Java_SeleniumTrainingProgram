package com.assign1;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;


public class ChatMessagesTM {
	public static void main(String[] args) {
		TreeMap<String,String> tmss = new TreeMap<>(new RComparator());
		
		tmss.put("name6", "msg1");
		tmss.put("name2", "msg2");
		tmss.put("name1", "msg3");
		tmss.put("name4", "msg4");
		
		Set<Entry<String,String>> sess=tmss.entrySet();
		
		System.out.println("Chats in descending order of names\n----------------------------");
		for(Entry<String,String> ess:sess) {
			System.out.println(ess.getKey()+"->"+ess.getValue());
		}
		
		
	}
}
class RComparator implements Comparator<String>{
	
	@Override
	public int compare(String s1,String s2) {
		return s2.compareTo(s1);
	}
}


