package com.springbootDBexample.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootDBexample.model.Ticket;
import com.springbootDBexample.repository.TicketRepository;



@Service
public class TicketService {
@Autowired
TicketRepository ticketRepo;
// Dependency Injection

public Ticket getTicketServ(int ticketid) {
Optional<Ticket> oticket= ticketRepo.findById(ticketid);
return oticket.get();
}

public Ticket bookTicketServ(Ticket ticket) {
return ticketRepo.save(ticket);
}
//
//public Ticket updateTicketServ(int tid, Ticket ticket) {
//return ticketRepo.updateTicketRepo(tid, ticket);
//}
//
//public Ticket cancelTicketServ(int ticketid) {
//Ticket ticket = ticketRepo.getTicketRepo(ticketid);
//ticketRepo.cancelTicketRepo(ticketid);
//return ticket;
//}

}