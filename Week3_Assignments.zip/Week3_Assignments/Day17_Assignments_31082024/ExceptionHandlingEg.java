package com.coll;

public class ExceptionHandlingEg {
	public static void main(String[] args) 
	{
		try {
		
				String str="abcd";
				String substr=str.substring(2,9);
				//StringIndexOutOfBoundsException
		
				int arr[]= {1, 2, 3, 4, 5};
				
				//ArrayIndexOutOfBoundsException
				for(int i=0;i<=arr.length;i++) {
					System.out.println(arr[i]);
				}
				
				met();
		}
		catch(StringIndexOutOfBoundsException se) {
			System.out.println("String index Exception"+se);
			
		}
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("Array index Exception"+ae);
		}
		catch(NumberFormatException ne) {
			System.out.println("Number Format Exception"+ne);
		}
		catch(Exception e) {
			System.out.println("Exception occured"+e);
			e.printStackTrace();
		}
		finally {
			System.out.println("finally");
		}
	}
	
	static void met() throws Exception{
		System.out.println("1......");
		try {
			String str="sdfsdfg";
			int val=Integer.parseInt(str);
			System.out.println("2.....");
			val*=1.1;
			System.out.println(val);
		}
		catch(Exception e) {
			System.out.println("Exception occured. Please retry with different input");
		}
		System.out.println("3.......");
	}
	
}
