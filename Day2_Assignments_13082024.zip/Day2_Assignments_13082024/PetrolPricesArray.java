package Samples;

public class PetrolPricesArray {
	 
	public static void main(String[] args) {
		int[] prices= {150,145,143,156,151,149};
		float average=0;
		int sum=0;
		for(int i=0;i<6;i++) {
			sum=sum+prices[i];
		}
		average=sum/6;
		System.out.println("Average of Petrol Prices is "+average);
		
	}
}