package com.exceleg;

import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWrite2Eg {
	
	static String sarr[][]= {{"dfgtyh","dgfdh","fghjyui"},{"fghrtyu","tryufghji","ffdhyuri"}};
	
	public static void main(String[] args) {
		try {
		
		//create workbook
		 Workbook wbook = new XSSFWorkbook();
		 
		//create sheet
		 Sheet st = wbook.createSheet("First Sheet");
		
		for(int i=0;i<sarr.length;++i) {
			 
			//Create row
			Row row=st.createRow(i);
			for(int j=0;j<sarr[0].length;j++) {
				//Create cell
				Cell cell = row.createCell(j);
			    cell.setCellValue(sarr[i][j]);
				System.out.println("Writing the element" +sarr[i][j]+"\t");
			}
			System.out.println();
		}
		 //FileOutputStream fos = new FileOutputStream("D:\\GAMA Training\\Excels\\FirstExcel.xlsx");
		
		FileOutputStream fos = new FileOutputStream("../SecondExcel.xlsx");//create in parent directory
		//write above excel to a file
		    wbook.write(fos);
	}catch(Exception e) {
		e.printStackTrace();
	}
}
}