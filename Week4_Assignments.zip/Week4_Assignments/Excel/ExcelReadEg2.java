package com.exceleg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg2 {

	public static void main(String[] args) throws FileNotFoundException,IOException {
		//open file
		FileInputStream fis=new FileInputStream("D:\\GAMA Training\\Excels\\FirstExcel.xlsx");

		//read workbook
		Workbook wbook=new XSSFWorkbook(fis);
		
		System.out.println("No. of sheets: "+wbook.getNumberOfSheets());
		
		//read sheet
		Sheet st=wbook.getSheetAt(0);
		
		int no_of_rows=st.getPhysicalNumberOfRows();
		for(int i=0;i<no_of_rows;i++) {
			//read rows
			Row row=st.getRow(i);
			int no_of_cols=row.getLastCellNum();
			
			for(int j=0;j<no_of_cols;j++) {
				//read cells
				Cell cell=row.getCell(j);
		
				System.out.println(cell.getStringCellValue());
			}
		}
		wbook.close();
		fis.close();
		
		
	}

}

