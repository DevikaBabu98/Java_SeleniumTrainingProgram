package com.junit5Eg2;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.junitchk.Arithmetic;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ArithmeticTest {

    //private  ArithmeticDay26  arithmetics;
	private   Arithmetic arithmetics = new Arithmetic();

    @BeforeAll
    static void befallmet() {
    	// arithmetics = new ArithmeticDay26();-> need to check this is not working for me
    	
    System.out.println("Before All method");	
    }
    
    @BeforeEach
    void befeachmet() {
    System.out.println("Before Each method");	
    }
    @Order(1)
    @Test
    @Tag("Feature1")
    void testMet() {
    }
}
