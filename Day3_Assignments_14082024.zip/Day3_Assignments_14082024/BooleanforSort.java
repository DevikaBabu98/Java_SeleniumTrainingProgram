package Samples;

public class BooleanforSort {
	
	public static void main(String[] args) {
		
		 int[] pincome= {4,7,1,5,9};
		 System.out.print("Array : ");
		 print(pincome);
		 System.out.print("Ascending order : ");
		 int[] aincome=sort(pincome,true);
	     print(aincome);
	     System.out.print("Descending order : ");
	     int[] dincome=sort(pincome,false);
	     print(dincome);
		
	}
		
		static int[] sort(int[] avalues, boolean ascending){
			 int i,j,temp;
			 for(i=0;i<avalues.length;i++) {
				 for(j=0;j<avalues.length-1;j++) {
					if(ascending) {
					 if(avalues[j]>avalues[j+1]) {
						 temp=avalues[j];
						 avalues[j]=avalues[j+1];
						 avalues[j+1]=temp;
					 	}
					 
					}
					else {
						 if(avalues[j]<avalues[j+1]) {
							 temp=avalues[j];
							 avalues[j]=avalues[j+1];
							 avalues[j+1]=temp;
						 }
					 }
					 
				 }
			 }
			 return avalues;
		 }
		 
		 
		 static void print (int arr[]) {
			 for(int i=0;i<arr.length;i++) {
				 System.out.print(arr[i]+"\t");
			 }
			 System.out.println();
		 }

	
}
