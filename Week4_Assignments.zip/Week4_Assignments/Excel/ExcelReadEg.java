package com.exceleg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg {

	public static void main(String[] args) throws FileNotFoundException,IOException {
		//open file
		FileInputStream fis=new FileInputStream("./firstexcel.xlsx");

		//read workbook
		Workbook wbook=new XSSFWorkbook(fis);
		
		System.out.println("No. of sheets: "+wbook.getNumberOfSheets());
		
		//read sheet
		Sheet st=wbook.getSheetAt(0);
		
		
		//read rows
		Row row=st.getRow(0);
			
		//read cells
		Cell cell=row.getCell(0);
		
		System.out.println(cell.getStringCellValue());
			
		wbook.close();
		fis.close();
		
		
	}

}

