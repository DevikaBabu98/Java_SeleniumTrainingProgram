package com.example.onetomany08102024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Onetomany08102024Application {

	public static void main(String[] args) {
		SpringApplication.run(Onetomany08102024Application.class, args);
	}

}
