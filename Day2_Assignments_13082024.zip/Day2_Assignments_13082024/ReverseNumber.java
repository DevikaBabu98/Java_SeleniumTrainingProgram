package Samples;

import java.util.Scanner;

public class ReverseNumber {
	
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter a number");
		int num= scanner.nextInt();
		int r=0;
		System.out.print("Reversed number is ");
		while(num!=0) {
			//r=(r*10)+(num%10);
			r=num%10;
			num=num/10;
			System.out.print(r+" ");
		}
	}
}
			
			
			
			
			
	

