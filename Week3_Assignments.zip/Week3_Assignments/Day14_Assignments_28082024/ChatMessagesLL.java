package com.coll;

import java.util.*;

class Chats{
	private String sender_name;
	private String msg;
	
	public Chats(String sender_name, String msg) {
		super();
		this.sender_name = sender_name;
		this.msg = msg;
	}
	
	@Override
	public String toString() {
		return "Chats [sender_name=" + sender_name + ", msg=" + msg + "]";
	}
}
public class ChatMessagesLL {
	public static void main(String[] args) {
		List<Chats> msgs = new LinkedList<>();
	
		//create Chats objects and add to above ll
		msgs.add(new Chats("name1","msg1"));
		msgs.add(new Chats("name2","msg2"));
		msgs.add(new Chats("name3","msg3"));
		msgs.add(new Chats("name4","msg4"));
		
	
		//Iterate and display
		System.out.println("\nList of Chats"+"\n-------------------------");
		for(Chats c:msgs) {
			System.out.println(c);
		}
	
		//reverse linked List
		Collections.reverse(msgs);
	
		//iterate and display reverse Linked list
		System.out.println("\nList of Chats after reversing"+"\n-------------------------");
		for(Chats c:msgs) {
			System.out.println(c);
		}
	
		
}
}
