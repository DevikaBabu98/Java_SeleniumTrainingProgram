package com.utils;

/*
1. Make constructor private
2. Create a static method for object creation
3. In above method create object only if not already created
4. use static member to find object already created
 */


//Singleton = can create one and only one object

public class ArrayUtils {
	private int array[];
	private static boolean object_created = false;

	//constructor
	private ArrayUtils(int array[]) {
		this.array = array;
	}
	
	public static ArrayUtils getInstance(int array[]) {
		ArrayUtils obj = null;
		if(object_created == false) {
			obj = new ArrayUtils(array);
			object_created = true;
		}
		return obj;
	}
	
	//min
	public int min() {
		int min_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min_val) {
				min_val = array[i];
			}
		}

		return min_val;
	}
	
	//max
	public int max() {
		int max_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] > max_val) {
				max_val = array[i];
			}
		}

		return max_val;
	}
	//avg
	public int avg() {
		int avg_val=0, sum=0;
		int n=array.length;
		for (int i = 0; i < n; i++) {
			sum=sum+array[i];
			
		}
		avg_val=avg_val+sum/n;
		return avg_val;
	}
	//etc...

}