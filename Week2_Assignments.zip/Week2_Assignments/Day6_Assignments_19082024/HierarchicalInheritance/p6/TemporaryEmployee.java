package com.p6;

import com.p5.Employee;

public class TemporaryEmployee extends Employee {

	private float hourlyPay;
	private String company_addr;
	
	public TemporaryEmployee(int eid,String name,float hourlyPay,String company_addr) {
		super(eid,name);
		this.hourlyPay=hourlyPay;
		this.company_addr=company_addr;
	}
	
	public void displayt() {
		displaye();
		System.out.println("Employee HourlyPay: "+hourlyPay+" Employee Company Address: "+company_addr);
	}
	
	
	
	
}